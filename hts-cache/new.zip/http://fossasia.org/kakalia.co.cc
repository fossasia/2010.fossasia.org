<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="http://fossasia.org/sites/default/files/fever_favicon.ico" type="image/x-icon" />
  <title>FOSSASIA | Page not found</title>
  <link type="text/css" rel="stylesheet" media="all" href="/modules/node/node.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/modules/system/defaults.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/modules/system/system.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/modules/system/system-menus.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/modules/user/user.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/cck/theme/content-module.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/ctools/css/ctools.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/date/date.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/dhtml_menu/dhtml_menu.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/filefield/filefield.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/logintoboggan/logintoboggan.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/panels/css/panels.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/video/css/video.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/views_slideshow/contrib/views_slideshow_singleframe/views_slideshow.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/views_slideshow/contrib/views_slideshow_thumbnailhover/views_slideshow.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/views_slideshow_jcarouselthumbs/views_slideshow.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/cck/modules/fieldgroup/fieldgroup.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/modules/views/css/views.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/kanji/style.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/kanji/local.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/kanji/sf/css/superfish.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/kanji/sf/css/theme.css?Y" /><link type="text/css" rel="stylesheet" media="print" href="/sites/all/themes/kanji/print.css?Y" /><link type="text/css" rel="stylesheet" media="all" href="http://fossasia.org/sites/default/files/customcssjs/css/custom.css?Y" />  <script type="text/javascript" src="/sites/all/modules/jquery_update/replace/jquery.min.js?Y"></script>
<script type="text/javascript" src="/misc/drupal.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/dhtml_menu/dhtml_menu.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/panels/js/panels.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/video/js/video.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/views_slideshow/js/jquery.cycle.all.min.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/views_slideshow/contrib/views_slideshow_singleframe/views_slideshow.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/views_slideshow/contrib/views_slideshow_thumbnailhover/views_slideshow.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/views_slideshow_ddblock/js/views_slideshow_ddblock.admin.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/views_slideshow_jcarouselthumbs/jcarousel/lib/jquery.jcarousel.js?Y"></script>
<script type="text/javascript" src="/sites/all/modules/views_slideshow_jcarouselthumbs/views_slideshow.js?Y"></script>
<script type="text/javascript" src="/sites/all/themes/kanji/sf/js/superfish.js?Y"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","dhtmlMenu":{"slide":"slide","clone":"clone","siblings":0,"relativity":0,"children":0,"doubleclick":0}});
//--><!]]>
</script>
  <!--[if IE]>
    <link type="text/css" rel="stylesheet" media="all" href="/sites/all/themes/kanji/ie_styles.css" />
  <![endif]-->
</head>
<body class=" one-sidebar">
  
  <div id="header">
        
    <div id="headerWrapper">
              
            
      <div id="siteName">
        <a href="/" title="Home"> <img src="http://fossasia.org/sites/default/files/fever_logo.png" alt="" id="logo" /></a>        <div id="siteInfo">
                    
                      <div id="siteSlogan">Free Software<br />Community<br />in Asia<br /></div>
                  </div><!-- /siteInfo -->
      </div> <!-- /siteName-->
        
              
    </div><!-- /headerWrapper -->
  </div><!-- /header -->

  <div id="container">
    <div id="inner">  
      <div id="contentWrapper">
         
        
                
               
        <div id="center">
                  
                  
                  
          <div id="content">        
                                                <h2 class="title" id="page-title">Page not found</h2>            The requested page could not be found.                      </div>
        
             
        </div><!-- /center --> 
    
                  <div id="sidebar_last" class="sidebar">
            <div id="block-block-19" class="clear-block block block-block odd">
      <h2>Twitter</h2>
    <div class="content with-subject">
    <a class="twitter-timeline" data-dnt="true" href="https://twitter.com/fossasia" data-widget-id="312420098352742400">Tweets by @fossasia</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>  </div>
</div>


<div id="block-block-22" class="clear-block block block-block even">
      <h2>Vietnam Software Development Outsourcing</h2>
    <div class="content with-subject">
    <a href="http://mbm.vn"><img src="/sites/default/files/mbm_logo_0.png" alt="Vietnam Software Development and Outsourcing" width="200" height="57"></a>  </div>
</div>


<div id="block-block-11" class="clear-block block block-block odd">
      <h2>Projects</h2>
    <div class="content with-subject">
    <div class="project-list"><ul><li><a title="Debian" href="http://www.debian.org/"><img src="../../../../../sites/default/files/project/debian.png" alt="Debian" width="75"></a></li><li><a href="http://www.drupal.org"><img src="/sites/default/files/project/drupal.png" alt="Drupal" width="68"></a></li><li><a href="http://fedoraproject.org"><img src="/sites/default/files/project/fedora.png" alt="" width="100"></a></li><li><a href="http://www.blackray.org"><img src="/sites/default/files/project/blackray.png" alt="BlackRay" width="100"></a></li><li><a href="http://lubuntu.net"><img src="/sites/default/files/project/lubuntu.png" alt="" width="100"></a></li><li><a href="http://mozilla.org"><img src="/sites/default/files/project/mozilla.png" alt="" width="100"></a></li><li><a title="OPENDESIGN.ASIA" href="http://opendesign.asia"><img src="/sites/default/files/project/opendesign.png" alt="OpenDesign.Asia" width="100"></a></li><li><a href="http://nosql-database.org"><img src="/sites/default/files/project/nosql.png" alt="" width="100"></a></li><li><a href="http://olpc.vn"><img src="/sites/default/files/project/olpc.png" alt="" width="100"></a></li><li><a href="http://status.net"><img src="/sites/default/files/project/statusnet.png" alt="" width="100"></a></li><li><a href="http://tiddlywiki.com"><img src="/sites/default/files/project/tiddlywiki.png" alt="" width="100"></a></li><li><a href="http://yacy.net"><img src="/sites/default/files/project/yacy.png" alt="YaCy.net" width="100"></a></li><li><a href="http://ubuntu-vn.org"><img src="/sites/default/files/project/ubuntu_vn.png" alt="" width="100"></a></li><li><a href="http://xpud.org"><img src="/sites/default/files/project/xpud.png" alt="xPUD" width="100"></a></li><li><a href="http://www.exoplatform.com"><img src="/sites/default/files/project/exo.png" alt="" width="100"></a></li><li><a href="http://freifunk.net/"><img src="../../../../../sites/default/files/project/freifunk.png" alt="" width="100"></a></li><li><a title="Joomla" href="http://www.joomla.org"><img src="/sites/default/files/project/joomla-logo.png" alt="Joomla" width="100"></a></li><li><a title="Libre Graphics" href="http://libregraphicsmeeting.org"><img src="/sites/default/files/project/libregraphics.png" alt="Libre Graphics" width="100"></a></li><li><a href="http://www.android.com"><img src="/sites/default/files/project/android.png" alt="Android" width="100"></a></li><li><a title="MariaDB" href="http://www.mariadb.org"><img src="/sites/default/files/project/mariadb.png" alt="MariaDB" width="100"></a></li><li><a title="TomatoCMS" href="http://tomatocms.com"><img src="/sites/default/files/project/tomatocms.png" alt="TomatoCMS" width="100"></a></li><li><a title="Sahana Eden" href="http://eden.sahanafoundation.org"><img src="/sites/default/files/project/sahana_eden.png" alt="Sahana Eden"></a></li><li><a title="TYPO 3" href="http://www.typo3.com/"><img src="../../../../../sites/default/files/project/typo3.png" alt="Typo 3"></a></li></ul></div>  </div>
</div>


<div id="block-block-21" class="clear-block block block-block even">
      <h2>Hotel Partner</h2>
    <div class="content with-subject">
    <a title="Hotel Cantho" href="http://hotelxoai.com"><img src="/sites/default/files/canthohotelmekong.png" alt="Hotel Cantho Vietnam Mekong" width="200" height="149"></a>  </div>
</div>


          </div>
              
                  <div id="postscript_bottom" class="blockregion">
            <div id="block-block-2" class="clear-block block block-block odd">
      <h2>Face Book</h2>
    <div class="content with-subject">
    <iframe scrolling="no" frameborder="0" allowtransparency="true" style="border: medium none; overflow: hidden; width: 658px; height: 206px;" src="http://www.facebook.com/plugins/likebox.php?id=126893747338271&amp;width=658&amp;connections=24&amp;stream=false&amp;header=false&amp;height=206"></iframe>  </div>
</div>


          </div>
         
      </div><!-- /contentWrapper -->
      
    </div><!-- /Inner -->
    
  </div><!-- /container -->
  
  <div id="footer">
    <div class="footer-text">Theme designed by <a href="http://www.carettedonny.be" title="Donny Carette">Donny Carette</a>
          </div>
                    
     
  </div><!-- /footer -->
  
  </body>
</html>